Ti.include('APPFAB/APP.MAIN.js','APPFAB/APP.SERVICES.js', 'APPFAB/APP.MODEL.js', 'APPFAB/APP.UI.js');

APP.init();
//APP.showTablet();
APP.showMobile();
//APP.postInit();
